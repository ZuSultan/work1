function myFunc() {
	let modal = document.getElementById('entrance');

	let btn = document.getElementById("right-block-first");

	let span = document.getElementsByClassName("block-enter")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}


function myFuncSecond() {
	let modal = document.getElementById('second-menu');

	let btn = document.getElementById("right-block-second");

	let span = document.getElementsByClassName("close")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}



function myFuncThird() {
	let fin = document.getElementById('entrance');

	let modal = document.getElementById('checkin');

	let btn = document.getElementById("second-link");

	let span = document.getElementsByClassName("block-enter-twoo")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	  fin.style.display = "none"
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}

function myFuncFour() {
	document.getElementById("map").classList.toggle("active");	
}

myFunc();

myFuncSecond();

myFuncThird();


function func() {
	document.getElementById("onn").classList.toggle('active');
}
function funct() {
	document.getElementById("on").classList.toggle('active');
}
function functi() {
	document.getElementById("onk").classList.toggle('active');
}
function functio() {
	document.getElementById("onkk").classList.toggle('active');
}
function functionn() {
	document.getElementById("onkkk").classList.toggle('active');
}
function functionnn() {
	document.getElementById("onkkkk").classList.toggle('active');
}
function functionnnn() {
	document.getElementById("onkkkkk").classList.toggle('active');
}
function functionnnnn() {
	document.getElementById("onkkkkkk").classList.toggle('active');
}
function kid() {
	document.getElementById("kon").classList.toggle('active');
}
function kidd() {
	document.getElementById("konn").classList.toggle('active');
}
function inn() {
	document.getElementById("inn").classList.toggle('active');
}
function innn() {
	document.getElementById("innn").classList.toggle('active');
}
function innnn() {
	document.getElementById("innnn").classList.toggle('active');
}
function yn() {
	document.getElementById("yn").classList.toggle('active');
}
function ynn() {
	document.getElementById("ynn").classList.toggle('active');
}
function ynnn() {
	document.getElementById("ynnn").classList.toggle('active');
}
function un() {
	document.getElementById("un").classList.toggle('active');
}
function unn() {
	document.getElementById("unn").classList.toggle('active');
}
function knn() {
	document.getElementById("knn").classList.toggle('active');
}
function knnn() {
	document.getElementById("knnn").classList.toggle('active');
}
function bn() {
	document.getElementById("bn").classList.toggle('active');
}
function bnn() {
	document.getElementById("bnn").classList.toggle('active');
}
function las() {
	document.getElementById("las").classList.toggle('active');
}

// gelocation
function clickToMap() {
	document.getElementById("mapcanvas").classList.toggle("none-active");
	function success(position) {
	    var s = document.querySelector('#status');
	    
	    if (s.className == 'success') {
	      // not sure why we're hitting this twice in FF, I think it's to do with a cached result coming back    
	      return;
	    }
	    
	    s.innerHTML = "";
	    s.className = 'success';
	    
	    // var mapcanvas = document.createElement('div');
	    // mapcanvas.id = 'mapcanvas';
	    // mapcanvas.style.height = '400px';
	    // mapcanvas.style.width = '560px';
	      
	    // document.querySelector('article').appendChild(mapcanvas);
	    
	    var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
	    var myOptions = {
	      zoom: 15,
	      center: latlng,
	      mapTypeControl: false,
	      navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
	      mapTypeId: google.maps.MapTypeId.ROADMAP
	    };
	    var map = new google.maps.Map(document.getElementById("mapcanvas"), myOptions);
	    
	    var marker = new google.maps.Marker({
	        position: latlng, 
	        map: map, 
	        title:"You are here! (at least within a "+position.coords.accuracy+" meter radius)"
	    });
	  }
	  function error(msg) {
	    var s = document.querySelector('#status');
	    s.innerHTML = typeof msg == 'string' ? msg : "";
	    s.className = 'fail';
	    
	    // console.log(arguments);
	  }
	  if (navigator.geolocation) {
	    navigator.geolocation.getCurrentPosition(success, error);
	  } else {
	    error('not supported');
	  }
}
